const Employee = require('../models/Employee');
const User = require('../models/User');

module.exports = {

    Query: {

        async employee(_, {ID}){

            return await Employee.findById(ID)

        },

        // async getEmployees(_, {amount}){
                
        //     return await Employee.find().sort
        // }
    },

    Mutation: {

        async createEmployee(_, {employeeInput: {first_name,last_name,email,gender,salary}}){

            const createEmployee = new Employee({

                first_name: first_name,
                last_name: last_name,
                email:email,
                gender:gender,
                salary:salary
            });

            const res = await createEmployee.save();
            console.log(res._doc);

            return{
                id: res.id,
                ...res._doc
            }
        },

        async createUser(_, {userInput: {username,email,password}}){

            const createUser = new User({

                username: username,
                email:email,
                password: password
            });

            const res = await createUser.save();
            console.log(res._doc);

            return{
                id: res.id,
                ...res._doc
            }
        },

        async deleteEmployee(_, {ID}) {

           const wasDeleted = (await Employee.deleteOne({ _id: ID})).deletedCount;
           return wasDeleted; 
        },

        async editEmployee(_, {ID, employeeInput: {first_name,last_name,email,salary,gender}}){

            const wasEdited = (await Employee.updateOne({_id: ID}, {first_name:first_name, last_name:last_name,email,salary,gender})).modifiedCount;
            return wasEdited;
        }

    }

}