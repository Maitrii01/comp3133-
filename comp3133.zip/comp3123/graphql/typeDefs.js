const { gql } = require('apollo-server');

module.exports = gql`

    type Employee {
        first_name: String
        last_name: String
        email: String
        gender: String
        salary: Int
    }

    type User {
        username: String
        email: String
        password: String
    }

    input UserInput {
        username: String
        email: String
        password: String
    }

    input EmployeeInput
    {
        first_name: String
        last_name: String
        email: String
        gender: String
        salary: Int
    }

    type Query {
        employee(ID: ID!): Employee!
        getEmployees(amount: Int): [Employee]
    }

    type Mutation {

        createEmployee(employeeInput :EmployeeInput): Employee!
        createUser(userInput :UserInput): User!
        deleteEmployee(ID: ID!): Boolean
        editEmployee(ID: ID!, employeeInput: EmployeeInput): Boolean
    }
`